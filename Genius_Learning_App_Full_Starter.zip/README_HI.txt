GENIUS LEARNING APP — FULL STARTER PACKAGE
By Ashish Sir | Genius Coaching Centre
=======================================

इस पैकेज में:
1) web/ — मोबाइल-अनुकूल PWA prototype (विषय, नोट्स/वीडियो लिंक, डेमो टेस्ट, स्थानीय प्रोफाइल)
2) server.js — Node.js API starter: विद्यार्थी रजिस्ट्रेशन/लॉगिन, संसाधन, टेस्ट रिजल्ट, शिक्षक endpoints
3) package.json — backend dependencies
4) android/ — Android APK बनाने की रूपरेखा
5) env.example — आवश्यक server environment variables

ईमानदार स्थिति:
- यह तैयार, signed APK नहीं है; इस वातावरण में Android SDK/keystore के साथ build और signing नहीं किया गया।
- API में शिक्षक endpoints मौजूद हैं, लेकिन पहले शिक्षक खाते को सुरक्षित तरीके से provision करना होगा। सार्वजनिक register endpoint केवल student role बनाता है।
- वेब prototype अभी API से जुड़ा हुआ नहीं है; backend endpoints starter हैं। Frontend integration, hosting, HTTPS, domain, production security review और deployment आवश्यक हैं।
- ऑनलाइन परिणाम तभी सुरक्षित रूप से उपयोग करें जब server-side quiz grading हो। वर्तमान submit endpoint दिए गए score को रिकॉर्ड करता है, इसलिए production में इसे प्रश्न/उत्तर सर्वर पर जाँचने के लिए बदलना चाहिए।
- पासवर्ड, ईमेल या निजी विद्यार्थी डेटा सार्वजनिक चैट/साझा डिवाइस पर न रखें।

BACKEND चलाने के लिए:
1. Node.js 20+ इंस्टॉल करें।
2. इस folder में terminal खोलें और `npm install` चलाएँ।
3. env.example की कॉपी `.env` नाम से बनाकर JWT_SECRET को लंबा, random secret दें।
4. अपने सिस्टम के अनुसार variables सेट करें, फिर `npm start` चलाएँ।
5. Health check: http://localhost:3000/api/health
ध्यान दें: `.env` को GitHub या सार्वजनिक जगह पर अपलोड न करें। HTTPS और rate limiting सहित सुरक्षा उपाय deployment से पहले जोड़ें।

Android APK:
- सरल विकल्प: Android Studio में Capacitor या Trusted Web Activity (TWA) project बनाएँ और hosted HTTPS PWA को package करें।
- Android SDK, package ID, signing key और app-store policy checks आवश्यक हैं।
- नीचे android/ANDROID_BUILD_GUIDE_HI.txt में चरण दिए गए हैं।
