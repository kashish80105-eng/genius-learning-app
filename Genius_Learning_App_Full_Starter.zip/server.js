// Genius Learning App — starter backend (Node.js + Express + SQLite)
// For learning/prototyping only. Review security, configure HTTPS and secrets before production.
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database(process.env.DB_PATH || "genius-learning.db");
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error("Set JWT_SECRET environment variable before starting.");
  process.exit(1);
}
app.use(cors({ origin: process.env.CORS_ORIGIN || false }));
app.use(express.json({ limit: "1mb" }));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 class_name TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'student',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS resources (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 url TEXT NOT NULL,
 type TEXT NOT NULL,
 class_name TEXT NOT NULL DEFAULT 'सभी कक्षाएँ',
 subject TEXT NOT NULL DEFAULT 'सभी विषय',
 created_by INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS quiz_results (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 quiz_title TEXT NOT NULL,
 score INTEGER NOT NULL,
 total INTEGER NOT NULL,
 submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

function auth(requiredRole) {
 return (req,res,next) => {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({error:"लॉगिन आवश्यक है"});
  try {
   req.user = jwt.verify(token, JWT_SECRET);
   if (requiredRole && req.user.role !== requiredRole) return res.status(403).json({error:"इस सुविधा की अनुमति नहीं है"});
   next();
  } catch { return res.status(401).json({error:"टोकन अमान्य या समाप्त हो गया है"}); }
 };
}
const validEmail = s => typeof s === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
app.get("/api/health", (req,res)=>res.json({ok:true,app:"Genius Learning App"}));

app.post("/api/auth/register", async (req,res)=>{
 try {
  const {name,email,password,className} = req.body || {};
  if (!name || !validEmail(email) || typeof password !== "string" || password.length < 8 || !className)
   return res.status(400).json({error:"नाम, सही ईमेल, कक्षा और कम-से-कम 8 अक्षरों का पासवर्ड आवश्यक है"});
  const hash = await bcrypt.hash(password, 12);
  const result = db.prepare("INSERT INTO users(name,email,password_hash,class_name,role) VALUES(?,?,?,?, 'student')")
   .run(String(name).trim().slice(0,80), email.toLowerCase(), hash, String(className).slice(0,20));
  res.status(201).json({message:"रजिस्ट्रेशन सफल",userId:result.lastInsertRowid});
 } catch(e) {
  if (String(e.message).includes("UNIQUE")) return res.status(409).json({error:"इस ईमेल से पहले ही खाता बना है"});
  res.status(500).json({error:"रजिस्ट्रेशन नहीं हो सका"});
 }
});
app.post("/api/auth/login", async (req,res)=>{
 const {email,password} = req.body || {};
 if (!validEmail(email) || typeof password !== "string") return res.status(400).json({error:"ईमेल और पासवर्ड दर्ज करें"});
 const user = db.prepare("SELECT * FROM users WHERE email=?").get(email.toLowerCase());
 if (!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"ईमेल या पासवर्ड गलत है"});
 const token = jwt.sign({id:user.id,name:user.name,role:user.role,className:user.class_name}, JWT_SECRET, {expiresIn:"8h"});
 res.json({token,user:{id:user.id,name:user.name,email:user.email,className:user.class_name,role:user.role}});
});
app.get("/api/me", auth(), (req,res)=>res.json({user:req.user}));
app.get("/api/resources", (req,res)=>{
 const rows = db.prepare("SELECT id,title,url,type,class_name AS className,subject,created_at AS createdAt FROM resources ORDER BY id DESC").all();
 res.json({resources:rows});
});
app.post("/api/resources", auth("teacher"), (req,res)=>{
 const {title,url,type,className,subject} = req.body || {};
 let parsed;
 try { parsed = new URL(url); } catch { return res.status(400).json({error:"सही URL दर्ज करें"}); }
 if (!["https:","http:"].includes(parsed.protocol) || !title || !type) return res.status(400).json({error:"शीर्षक, प्रकार और सही URL आवश्यक हैं"});
 const result = db.prepare("INSERT INTO resources(title,url,type,class_name,subject,created_by) VALUES(?,?,?,?,?,?)")
  .run(String(title).slice(0,160),parsed.href,String(type).slice(0,40),String(className||"सभी कक्षाएँ").slice(0,20),String(subject||"सभी विषय").slice(0,60),req.user.id);
 res.status(201).json({id:result.lastInsertRowid,message:"संसाधन जोड़ दिया गया"});
});
app.delete("/api/resources/:id", auth("teacher"), (req,res)=>{
 const result=db.prepare("DELETE FROM resources WHERE id=?").run(Number(req.params.id));
 if (!result.changes) return res.status(404).json({error:"संसाधन नहीं मिला"});
 res.json({message:"संसाधन हटा दिया गया"});
});
app.post("/api/quizzes/submit", auth(), (req,res)=>{
 const {quizTitle,score,total}=req.body||{};
 if (!quizTitle || !Number.isInteger(score) || !Number.isInteger(total) || total<1 || score<0 || score>total || total>200)
  return res.status(400).json({error:"टेस्ट स्कोर अमान्य है"});
 const result=db.prepare("INSERT INTO quiz_results(user_id,quiz_title,score,total) VALUES(?,?,?,?)")
  .run(req.user.id,String(quizTitle).slice(0,120),score,total);
 res.status(201).json({id:result.lastInsertRowid,message:"रिजल्ट सेव हो गया"});
});
app.get("/api/results/mine", auth(), (req,res)=>{
 const results=db.prepare("SELECT quiz_title AS quizTitle,score,total,submitted_at AS submittedAt FROM quiz_results WHERE user_id=? ORDER BY id DESC").all(req.user.id);
 res.json({results});
});
app.get("/api/teacher/results", auth("teacher"), (req,res)=>{
 const results=db.prepare(`SELECT u.name,u.email,u.class_name AS className,q.quiz_title AS quizTitle,q.score,q.total,q.submitted_at AS submittedAt
 FROM quiz_results q JOIN users u ON u.id=q.user_id ORDER BY q.id DESC LIMIT 500`).all();
 res.json({results});
});
app.listen(PORT,()=>console.log(`Genius Learning API listening on port ${PORT}`));
