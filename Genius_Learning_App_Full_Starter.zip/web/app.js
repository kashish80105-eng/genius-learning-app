const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const dialog = $("#subjectDialog");
$$("[data-subject]").forEach(btn => btn.addEventListener("click", () => {
  $("#dialogTitle").textContent = btn.dataset.subject;
  dialog.showModal();
}));
$("#closeDialog").addEventListener("click", () => dialog.close());
$("#dialogNotes").addEventListener("click", () => dialog.close());

const STORE_KEY = "genius-learning-resources-v1";
function getResources(){ try{return JSON.parse(localStorage.getItem(STORE_KEY)||"[]")}catch{return []} }
function renderResources(){
  const list=$("#resourcesList"), resources=getResources();
  list.innerHTML="";
  if(!resources.length){list.innerHTML='<p class="hint">अभी कोई लिंक नहीं जोड़ा गया है। ऊपर फॉर्म भरकर नोट्स या वीडियो जोड़ें।</p>';return}
  resources.forEach((r,i)=>{
    const item=document.createElement("div"); item.className="resource-item";
    const info=document.createElement("div"), title=document.createElement("b"), meta=document.createElement("small"), link=document.createElement("a"), remove=document.createElement("button");
    title.textContent=r.title; meta.textContent=r.type; link.href=r.url; link.target="_blank"; link.rel="noopener noreferrer"; link.textContent="खोलें ↗";
    remove.type="button"; remove.textContent="हटाएँ"; remove.className="answer"; remove.style.padding="7px"; remove.addEventListener("click",()=>{const next=getResources();next.splice(i,1);localStorage.setItem(STORE_KEY,JSON.stringify(next));renderResources()});
    info.append(title,meta);item.append(info,link,remove);list.append(item);
  });
}
$("#resourceForm").addEventListener("submit",e=>{
  e.preventDefault();
  const title=$("#resourceTitle").value.trim(), url=$("#resourceUrl").value.trim(), type=$("#resourceType").value;
  try{const parsed=new URL(url);if(!["http:","https:"].includes(parsed.protocol))throw Error();}
  catch{$("#resourceUrl").setCustomValidity("कृपया सही https:// या http:// लिंक डालें।");$("#resourceUrl").reportValidity();return}
  $("#resourceUrl").setCustomValidity("");
  const items=getResources();items.unshift({title,url,type});localStorage.setItem(STORE_KEY,JSON.stringify(items));
  e.target.reset();renderResources();
});
renderResources();

const questions=[
 {q:"12 × 8 का मान कितना है?",a:["84","96","108","86"],correct:1,why:"12 × 8 = 96।"},
 {q:"पौधे अपना भोजन मुख्य रूप से किस प्रक्रिया से बनाते हैं?",a:["श्वसन","पाचन","प्रकाश संश्लेषण","वाष्पीकरण"],correct:2,why:"प्रकाश संश्लेषण में पौधे प्रकाश की सहायता से भोजन बनाते हैं।"},
 {q:"भारत की राजधानी कौन-सी है?",a:["पटना","मुंबई","नई दिल्ली","कोलकाता"],correct:2,why:"भारत की राजधानी नई दिल्ली है।"},
 {q:"Water का हिंदी अर्थ क्या है?",a:["आग","पानी","हवा","मिट्टी"],correct:1,why:"Water का हिंदी अर्थ पानी है।"},
 {q:"कंप्यूटर का मुख्य प्रोसेसिंग भाग कौन-सा है?",a:["CPU","Mouse","Monitor","Keyboard"],correct:0,why:"CPU निर्देशों को प्रोसेस करता है।"}
];
let qIndex=0,score=0,answered=false;
function renderQuestion(){
 const q=questions[qIndex];answered=false;
 $("#questionText").textContent=`प्रश्न ${qIndex+1}. ${q.q}`;
 $("#answers").innerHTML="";
 q.a.forEach((ans,i)=>{const b=document.createElement("button");b.className="answer";b.textContent=String.fromCharCode(65+i)+". "+ans;b.addEventListener("click",()=>chooseAnswer(i,b));$("#answers").append(b)});
 $("#quizProgress").textContent=`${qIndex+1} / ${questions.length}`;
 $("#quizResult").textContent="";
 $("#nextQuestion").textContent=qIndex===questions.length-1?"फिर से टेस्ट दें":"अगला प्रश्न";
}
function chooseAnswer(i,button){
 if(answered)return;answered=true;
 const q=questions[qIndex], buttons=$$(".answer");
 buttons.forEach((b,j)=>{b.disabled=true;if(j===q.correct)b.classList.add("correct")});
 if(i===q.correct){score++;button.classList.add("correct");$("#quizResult").textContent="सही जवाब! "+q.why}
 else{button.classList.add("wrong");$("#quizResult").textContent="सही उत्तर: "+q.a[q.correct]+". "+q.why}
}
$("#nextQuestion").addEventListener("click",()=>{
 if(!answered){$("#quizResult").textContent="आगे बढ़ने से पहले एक विकल्प चुनें।";return}
 if(qIndex===questions.length-1){$("#questionText").textContent=`टेस्ट पूरा! आपका स्कोर ${score}/${questions.length} है।`;$("#answers").innerHTML="";$("#quizProgress").textContent="पूरा हुआ";$("#quizResult").textContent="अच्छा प्रयास! दोबारा अभ्यास करके अपना स्कोर बढ़ाएँ।";$("#nextQuestion").textContent="फिर से शुरू करें";qIndex=0;score=0;answered=true;$("#nextQuestion").onclick=()=>{ $("#nextQuestion").onclick=null;renderQuestion() };return}
 qIndex++;renderQuestion();
});
renderQuestion();

const PROFILE_KEY="genius-learning-profile-v1";
function loadProfile(){try{const p=JSON.parse(localStorage.getItem(PROFILE_KEY)||"null");if(p){$("#studentName").value=p.name;$("#studentClass").value=p.className;$("#profileMessage").textContent=`स्वागत है, ${p.name}! आपकी प्रोफाइल इस डिवाइस पर सेव है।`}}catch{}}
$("#profileForm").addEventListener("submit",e=>{e.preventDefault();const p={name:$("#studentName").value.trim(),className:$("#studentClass").value};localStorage.setItem(PROFILE_KEY,JSON.stringify(p));$("#profileMessage").textContent=`स्वागत है, ${p.name}! आपकी प्रोफाइल इस डिवाइस पर सेव हो गई।`;});
loadProfile();

let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("#installBtn").classList.remove("hidden")});
$("#installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("#installBtn").classList.add("hidden")});
if("serviceWorker" in navigator && location.protocol.startsWith("http")) window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));
